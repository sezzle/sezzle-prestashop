<div align="center">
    <a href="https://sezzle.com">
        <img src="https://media.sezzle.com/branding/2.0/Sezzle_Logo_FullColor.svg" width="300px" alt="Sezzle" />
    </a>
</div>

# Sezzle Prestashop Module Changelog

## Version 2.0.5

_Thu 7 Feb 2023_

### Supported Editions & Versions

Tested and verified in clean installations of Prestashop 1.7.x.x and 8.x.x.

### Highlights

- Added check if order is authorized, if not, an error message is thrown and order is not created.

## Version 2.0.4

_Thu 2 Feb 2023_

### Supported Editions & Versions

Tested and verified in clean installations of Prestashop 1.7.x.x and 8.x.x.

### Highlights

- Auto save of merchant UUID during Sezzle admin config save.